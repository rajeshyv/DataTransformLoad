package utils;

import java.io.File;

public class GlobalAccessor {
	
	
	public static File positionsCsv;

	public static File instrumentCsv;

}
