package utils;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dao {
	
	
	public static Properties properties;
	public static Connection connection=null;
	
	public static Connection dbConnect() throws Exception {
		
		try {
			FileReader reader = new FileReader("src/test/java/resources/config.properties");

			properties = new Properties();
			properties.load(reader);
			
			Class.forName(properties.getProperty("jdbc.driver"));
			connection = DriverManager.getConnection(properties.getProperty("jdbc.url"),
					properties.getProperty("jdbc.username"),
					properties.getProperty("jdbc.password"));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
		
		
		}

}
