package utils;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import model.CSVConfigWithListData;
import model.ContentRecord;

public class CSVReaderAndWriter {

	public List<ContentRecord> getCsvRecordsListWithIgnoreHeaderInQuoted(String csvFile,
			CSVConfigWithListData csvConfig, String noOfRowsIgnoredAtStart) throws IOException {

		List<ContentRecord> contentRecords = new ArrayList<>();

		try (FileReader in = new FileReader(csvFile);
				CSVParser csvFileParser = new CSVParser(in, CSVFormat.newFormat(',').withQuote('"')
						.withIgnoreEmptyLines().withIgnoreHeaderCase().withHeader(csvConfig.getHeaders()))) {

			List<CSVRecord> records = csvFileParser.getRecords();

			contentRecords = csvConfig.mapCSVToContentRecordsListWithIgnoreHeader(records, noOfRowsIgnoredAtStart);

		} catch (IOException e) {

			throw new IOException("Error occurred while reading the CSV file: " + e.getMessage(), e);
		}

		return contentRecords;
	}
}
