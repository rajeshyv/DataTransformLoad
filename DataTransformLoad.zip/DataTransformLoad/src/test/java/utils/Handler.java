package utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import model.ContentRecord;
import model.InstrumentCsvConfig;
import model.InstrumentVO;
import model.PositionCsvConfig;
import model.PositionVO;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class Handler {

	private static List<ContentRecord> instrumentCsvRecords;
	private static List<ContentRecord> positionsCsvRecords;
	private static Connection connection = null;
	private static Statement stmt;

	static String noOfIgnoredAtStart = "1";

	public static void checkInputFilesExists(String instrumentFile, String positionsFile) {

		File instrumentCsvFile = new File(instrumentFile);
		GlobalAccessor.instrumentCsv = instrumentCsvFile;

		if (instrumentCsvFile.exists()) {
			TestLogger.info("Instrument CSV File exist in the location");
		} else {
			TestLogger.info("Instrument CSV File does not exist in the location");

		}

		File positionsCsvFile = new File(positionsFile);
		GlobalAccessor.positionsCsv = positionsCsvFile;

		if (positionsCsvFile.exists()) {
			TestLogger.info("Positions CSV File exist in the location");
		} else {
			TestLogger.info("Positions CSV File does not exist in the location");
		}
	}

	public static void readingDataFromCSV(String instrumentFile, String positionsFile) throws Exception {

		try {
			CSVReaderAndWriter reader = new CSVReaderAndWriter();
			instrumentCsvRecords = reader.getCsvRecordsListWithIgnoreHeaderInQuoted(instrumentFile,
					new InstrumentCsvConfig(), noOfIgnoredAtStart);
			System.out.println(instrumentCsvRecords.size());

		} catch (Exception e) {
			TestLogger.info(" Reading instrumnet csv data failed");
			e.printStackTrace();
		}

		try {
			CSVReaderAndWriter reader = new CSVReaderAndWriter();
			positionsCsvRecords = reader.getCsvRecordsListWithIgnoreHeaderInQuoted(positionsFile,
					new PositionCsvConfig(), noOfIgnoredAtStart);
			System.out.println(positionsCsvRecords.size());

		} catch (Exception e) {

			TestLogger.info(" Reading position csv data failed");
			e.printStackTrace();
		}

	}

	public static void loadDataIntoDataBase() throws Exception {

		connection = new Dao().dbConnect();
		stmt = connection.createStatement();
		deleteAllRecords(connection, stmt);

		String insertQuery = "insert into instrumentdetails(ID,InstrumentName,ISIN,UnitPrice) values(?,?,?,?)";
		PreparedStatement pStmt = connection.prepareStatement(insertQuery);
		for (Iterator<ContentRecord> it = instrumentCsvRecords.iterator(); it.hasNext();) {

			InstrumentVO instrumentVO = (InstrumentVO) it.next();
			pStmt.setString(1, instrumentVO.getId());
			pStmt.setString(2, instrumentVO.getInstrumentName());
			pStmt.setString(3, instrumentVO.getIsin());
			pStmt.setString(4, instrumentVO.getUnitPrice());
			pStmt.executeUpdate();

		}

		insertQuery = "insert into positiondetails(ID,positionID,ISIN,Quantity) values(?,?,?,?)";
		pStmt = connection.prepareStatement(insertQuery);
		for (Iterator<ContentRecord> it = positionsCsvRecords.iterator(); it.hasNext();) {

			PositionVO instrumentVO = (PositionVO) it.next();
			pStmt.setString(1, instrumentVO.getId());
			pStmt.setString(2, instrumentVO.getpositionid());
			pStmt.setString(3, instrumentVO.getIsin());
			pStmt.setString(4, instrumentVO.getQuantity());
			pStmt.executeUpdate();

		}
	}

	public static boolean doTransformAndLoad() throws Exception {
		boolean status = false;
		try {

			stmt = connection.createStatement();

			String insertQuery = "INSERT INTO PositionReport (ID,PositionID, ISIN, Quantity, TotalPrice)\r\n"
					+ "SELECT \r\n" + "    ROW_NUMBER() OVER (order by p.PositionID asc) as ID,\r\n"
					+ "    p.PositionID,                       -- Position ID from PositionDetails\r\n"
					+ "    p.ISIN,                             -- ISIN from PositionDetails\r\n"
					+ "    p.Quantity,                         -- Quantity from PositionDetails\r\n"
					+ "    (p.Quantity * i.UnitPrice) AS TotalPrice  -- Calculate Total Price (Quantity * UnitPrice)\r\n"
					+ "FROM \r\n" + "    PositionDetails p\r\n" + "JOIN \r\n"
					+ "    InstrumentDetails i ON p.ISIN = i.ISIN";
			PreparedStatement pStmt = connection.prepareStatement(insertQuery);
			pStmt.executeUpdate();
			status = true;

		} catch (Exception e) {
			System.out.println("Data Transformation Failed......");

		}
		return status;
	}

	public static void deleteAllRecords(Connection conn1, Statement stsmt) throws SQLException {

		stmt = conn1.createStatement();
		String deleteQuery = "DELETE FROM PositionReport";
		stmt.executeUpdate(deleteQuery);
		deleteQuery = "DELETE FROM PositionDetails";
		stmt.executeUpdate(deleteQuery);
		deleteQuery = "DELETE FROM InstrumentDetails";
		stmt.executeUpdate(deleteQuery);

	}

	public static void sqlToCsvExporter(Properties p) {
		String CSV_FILE_PATH = p.getProperty("PositionReport");

		String SQL_QUERY = "SELECT * FROM PositionReport";

		try {

			stmt = connection.createStatement();
			ResultSet resultSet = stmt.executeQuery(SQL_QUERY);

			FileWriter csvWriter = new FileWriter(CSV_FILE_PATH);

			ResultSetMetaData metaData = resultSet.getMetaData();
			int columnCount = metaData.getColumnCount();

			for (int i = 1; i <= columnCount; i++) {
				csvWriter.append(metaData.getColumnName(i));
				if (i < columnCount) {
					csvWriter.append(",");
				}
			}
			csvWriter.append("\n");

			while (resultSet.next()) {
				for (int i = 1; i <= columnCount; i++) {
					csvWriter.append(resultSet.getString(i));
					if (i < columnCount) {
						csvWriter.append(",");
					}
				}
				csvWriter.append("\n");
			}

			resultSet.close();
			stmt.close();
			connection.close();
			csvWriter.flush();
			csvWriter.close();

			System.out.println("CSV file generated successfully.");

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
	}

	public static boolean fileChecker(Properties p) {
		String directoryPath = p.getProperty("outputFolderPath");
		String fileName = "PositionReport.csv";

		String filePath = directoryPath + "/" + fileName;

		File file = new File(filePath);

		if (file.exists() && !file.isDirectory()) {
			System.out.println("File '" + fileName + "' exists at the location: " + filePath);
			return true;
		} else {
			System.out.println("File '" + fileName + "' does not exist at the location: " + filePath);
			return false;
		}
	}

}
