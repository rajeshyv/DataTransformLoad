package utils;

public class FileLocations {
	
	public final String instrumentCsv = System.getProperty("instrumentCsvPath");
	
	public final String positionsCsv = System.getProperty("positionsCsvPath");
		

}
