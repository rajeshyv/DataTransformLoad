package stepdefinitions;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utils.FileLocations;
import utils.GlobalAccessor;
import utils.Handler;
import utils.TestLogger;

public class Steps {
    
    private Properties p;
    private String instrumentCsvPath;
    private String positionsCsvPath;
    
    // Constructor to load the properties
    public Steps() throws IOException {
        p = loadProperties("resources/config.properties");
        instrumentCsvPath = p.getProperty("instrumentCsvPath");
        positionsCsvPath = p.getProperty("positonsCsvPath");
    }
    
    // Helper method to load properties
    private Properties loadProperties(String fileName) throws IOException {
        try (InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName)) {
            Properties properties = new Properties();
            if (inputStream != null) {
                properties.load(inputStream);
            } else {
                throw new IOException("Property file not found: " + fileName);
            }
            return properties;
        }
    }
    
    @Given("the user retrieves input files from a specified location")
    public void the_user_retrieves_input_files_from_a_specified_location() {
        TestLogger.info("Instrument Csv file is in the location: " + instrumentCsvPath);
        TestLogger.info("Positions Csv file is in the location: " + positionsCsvPath);
    }

    @When("the user checks that the InstrumentDetails and PositionDetails files exist at the location")
    public void the_user_checks_that_the_instrument_details_and_position_details_files_exist_at_the_location() {
        Handler.checkInputFilesExists(instrumentCsvPath, positionsCsvPath);
        Assert.assertTrue(GlobalAccessor.instrumentCsv.exists(), "Instrument CSV file does not exist.");
        Assert.assertTrue(GlobalAccessor.positionsCsv.exists(), "Positions CSV file does not exist.");
    }

    @Then("the system reads the CSV files")
    public void the_system_reads_the_csv_files() throws Exception {
        Handler.readingDataFromCSV(instrumentCsvPath, positionsCsvPath);
    }

    @Then("the data is loaded into the corresponding database tables")
    public void the_data_is_loaded_into_the_corresponding_database_tables() throws Exception {
        Handler.loadDataIntoDataBase();
    }

    @When("the user performs data transformation")
    public void the_user_performs_data_transformation() throws Exception {
        Handler.doTransformAndLoad();
    }

    @Then("the transformed data is loaded into the Positions table")
    public void the_transformed_data_is_loaded_into_the_positions_table() {
        Handler.sqlToCsvExporter(p);
    }

    @Then("a Position report is generated")
    public void a_position_report_is_generated() {
        Assert.assertTrue(Handler.fileChecker(p), "Output CSV file generation failed");
    }
}
