package model;

public abstract class ContentRecord {

}
