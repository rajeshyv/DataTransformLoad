package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.csv.CSVRecord;

public class PositionCsvConfig implements CSVConfigWithListData{
	
	@Override
	public String[] getHeaders() {
		
		return new String[] {
				"ID" , "positionid" , "ISIN" ,"quantity"
		};
		
		
		
	}

	@Override
	public List<ContentRecord> mapCSVToContentRecordsListWithIgnoreHeader(List<CSVRecord> csvRecordList,
			String noOfRowsIgnoreAtStart) {
		
				int noOfRowsIgnoredAtStartInt = Integer.parseInt(noOfRowsIgnoreAtStart);
				if (csvRecordList == null || csvRecordList.isEmpty()) {
				return Collections. emptyList();
				}
				List<ContentRecord> returnList = new ArrayList<>();
				for (int index = noOfRowsIgnoredAtStartInt; index < csvRecordList.size(); index++) {
				CSVRecord csvRecord = csvRecordList.get(index);
				
				PositionVO positionVO = new PositionVO();
				positionVO.setId(csvRecord.get("ID"));
				positionVO.setpositionid(csvRecord.get("positionid"));
				positionVO.setIsin(csvRecord.get("ISIN"));
				positionVO.setQuantity(csvRecord.get("quantity"));
				returnList.add(positionVO);
				}
				
				return returnList;

	}
}
