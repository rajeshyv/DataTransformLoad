package model;

import java.util.List;

import org.apache.commons.csv.CSVRecord;

public interface CSVConfigWithListData {
	
	String[] getHeaders();
	//String[] getInstrumentHeaders();
	//String[] getPostionHeaders();
	
	List<ContentRecord> mapCSVToContentRecordsListWithIgnoreHeader(List<CSVRecord> csvRecordList, String noOfRowsIgnoreAtStart);
		
	

}
