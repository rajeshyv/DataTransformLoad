package model;

import lombok.Data;

@Data
public class PositionVO extends ContentRecord {

	public String id;
	public String positionid;
	public String isin;
	public String quantity;
	

	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	
	public String getpositionid() {
		return positionid;
	}


	public void setpositionid(String positionid) {
		this.positionid = positionid;
	}


	public String getIsin() {
		return isin;
	}


	public void setIsin(String isin) {
		this.isin = isin;
	}


	public String getQuantity() {
		return quantity;
	}


	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	
	
	public String toString() {
		return id + "," + positionid + "," + isin + "," + quantity;
	}
	

}
