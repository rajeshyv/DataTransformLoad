package model;

import lombok.Data;

@Data
public class InstrumentVO extends ContentRecord {

	public String id;
	public String instrumentName;
	public String isin;
	public String unitPrice;
	

	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}

	public String getInstrumentName() {
		return instrumentName;
	}


	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}


	public String getIsin() {
		return isin;
	}


	public void setIsin(String isin) {
		this.isin = isin;
	}


	public String getUnitPrice() {
		return unitPrice;
	}


	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	
	
	public String toString() {
		return id + "," + instrumentName + "," + isin + "," + unitPrice;
	}


	
	

}
